<?php

return [

    'name'              => 'Otp',
    'description'       => 'This is my awesome module',

];